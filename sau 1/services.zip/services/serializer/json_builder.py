from __future__ import annotations

from typing import Dict, List, Any, Optional

from services.models.block import Block
from services.diff.paragraph_diff import diff_words
from services.diff.table_diff import diff_table
from services.diff.shape_diff import diff_shape
from services.diff.image_diff import images_equal, build_image_change


def _section_key(h: Optional[str]) -> str:
    return h if h else "(No heading)"


def _serialize_block_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None

    return {
        "uid": block.uid,
        "type": block.type,
        "order": block.order,
        "heading": block.heading_ctx,
        "content": block.node.content,
        "preview_text": block.preview_text,
    }


def _build_context(
    blocks: List[Block],
    index: int,
) -> Dict[str, Optional[Dict[str, Any]]]:
    prev_block = blocks[index - 1] if index - 1 >= 0 else None
    next_block = blocks[index + 1] if index + 1 < len(blocks) else None

    return {
        "previous": _serialize_block_side(prev_block),
        "next": _serialize_block_side(next_block),
    }


def _build_change(
    cid: int,
    change_type: str,
    heading: Optional[str],
    order: int,
    left: Optional[Dict[str, Any]],
    right: Optional[Dict[str, Any]],
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "id": cid,
        "heading": heading,
        "type": change_type,
        "order": order,
        "left": left,
        "right": right,
        **(extra or {}),
    }


def build_ui_json(
    a_blocks: List[Block],
    b_blocks: List[Block],
    opcodes,
) -> Dict[str, Any]:
    sections_map: Dict[str, Dict[str, Any]] = {}
    flat_changes: List[Dict[str, Any]] = []

    cid = 1

    def add_change(change: Dict[str, Any]):
        nonlocal cid

        heading = _section_key(change.get("heading"))
        if heading not in sections_map:
            sections_map[heading] = {
                "heading": heading,
                "changes": [],
            }

        sections_map[heading]["changes"].append(change)
        flat_changes.append(change)

    for tag, i1, i2, j1, j2 in opcodes:
        if tag == "equal":
            continue

        if tag == "insert":
            for j in range(j1, j2):
                b = b_blocks[j]

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{b.type}_inserted",
                        heading=b.heading_ctx,
                        order=b.order,
                        left=None,
                        right=_serialize_block_side(b),
                        extra={
                            "left_context": None,
                            "right_context": _build_context(b_blocks, j),
                        },
                    )
                )
                cid += 1

        elif tag == "delete":
            for i in range(i1, i2):
                a = a_blocks[i]

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{a.type}_deleted",
                        heading=a.heading_ctx,
                        order=a.order,
                        left=_serialize_block_side(a),
                        right=None,
                        extra={
                            "left_context": _build_context(a_blocks, i),
                            "right_context": None,
                        },
                    )
                )
                cid += 1

        elif tag == "replace":
            pairs = min(i2 - i1, j2 - j1)

            for k in range(pairs):
                ai = i1 + k
                bj = j1 + k

                a = a_blocks[ai]
                b = b_blocks[bj]

                heading = b.heading_ctx or a.heading_ctx
                order = min(a.order, b.order)

                if a.type == "paragraph" and b.type == "paragraph":
                    old_text = a.node.content.get("text", "") or ""
                    new_text = b.node.content.get("text", "") or ""

                    if old_text != new_text or a.node.content != b.node.content:
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="paragraph_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_block_side(a),
                                right=_serialize_block_side(b),
                                extra={
                                    "diff_spans": diff_words(old_text, new_text),
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                if a.type == "table" and b.type == "table":
                    table_changes = diff_table(a.node, b.node)

                    if table_changes:
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="table_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_block_side(a),
                                right=_serialize_block_side(b),
                                extra={
                                    "table_changes": table_changes,
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                if a.type == "shape" and b.type == "shape":
                    shape_changes = diff_shape(a.node, b.node)

                    add_change(
                        _build_change(
                            cid=cid,
                            change_type="shape_modified",
                            heading=heading,
                            order=order,
                            left=_serialize_block_side(a),
                            right=_serialize_block_side(b),
                            extra={
                                "shape_changes": shape_changes,
                                "left_context": _build_context(a_blocks, ai),
                                "right_context": _build_context(b_blocks, bj),
                            },
                        )
                    )
                    cid += 1
                    continue

                if a.type == "image" and b.type == "image":
                    if not images_equal(a.node, b.node):
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="image_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_block_side(a),
                                right=_serialize_block_side(b),
                                extra={
                                    "image_change": build_image_change(a.node, b.node),
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{a.type}_to_{b.type}_modified",
                        heading=heading,
                        order=order,
                        left=_serialize_block_side(a),
                        right=_serialize_block_side(b),
                        extra={
                            "left_context": _build_context(a_blocks, ai),
                            "right_context": _build_context(b_blocks, bj),
                        },
                    )
                )
                cid += 1

            for i in range(i1 + pairs, i2):
                a = a_blocks[i]

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{a.type}_deleted",
                        heading=a.heading_ctx,
                        order=a.order,
                        left=_serialize_block_side(a),
                        right=None,
                        extra={
                            "left_context": _build_context(a_blocks, i),
                            "right_context": None,
                        },
                    )
                )
                cid += 1

            for j in range(j1 + pairs, j2):
                b = b_blocks[j]

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{b.type}_inserted",
                        heading=b.heading_ctx,
                        order=b.order,
                        left=None,
                        right=_serialize_block_side(b),
                        extra={
                            "left_context": None,
                            "right_context": _build_context(b_blocks, j),
                        },
                    )
                )
                cid += 1

    ordered_sections = sorted(
        sections_map.values(),
        key=lambda x: min(
            (
                c.get("order", 0)
                for c in x["changes"]
            ),
            default=0,
        ),
    )

    for section in ordered_sections:
        section["changes"] = sorted(
            section["changes"],
            key=lambda x: (x.get("order", 0), x.get("id", 0)),
        )

    return {
        "sections": ordered_sections,
        "changes": sorted(
            flat_changes,
            key=lambda x: (x.get("order", 0), x.get("id", 0)),
        ),
    }