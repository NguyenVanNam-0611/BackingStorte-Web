from __future__ import annotations

from typing import Dict, Any, Optional
from services.models.docnode import DocNode


def images_equal(a: Optional[DocNode], b: Optional[DocNode]) -> bool:
    if a is None and b is None:
        return True

    if a is None or b is None:
        return False

    if a.type != "image" or b.type != "image":
        return False

    a_hash = a.content.get("sha256") or a.content.get("hash")
    b_hash = b.content.get("sha256") or b.content.get("hash")

    if a_hash and b_hash:
        return a_hash == b_hash

    return (
        a.content.get("width") == b.content.get("width")
        and a.content.get("height") == b.content.get("height")
        and (a.content.get("name") or "") == (b.content.get("name") or "")
    )


def _image_payload(node: Optional[DocNode]) -> Optional[Dict[str, Any]]:
    if node is None:
        return None

    content = node.content or {}

    return {
        "uid": node.uid,
        "type": "image",
        "display_type": "image",
        "order": getattr(node, "order", 0),
        "path": getattr(node, "path", ""),
        "image": {
            "name": content.get("name"),
            "ext": content.get("ext"),
            "width": content.get("width"),
            "height": content.get("height"),
            "hash": content.get("hash"),
            "sha256": content.get("sha256"),
            "data_uri": content.get("data_uri"),
        },
        "text": content.get("text", ""),
        "caption": content.get("caption", ""),
    }


def build_image_change(
    a: Optional[DocNode],
    b: Optional[DocNode],
) -> Dict[str, Any]:
    original_payload = _image_payload(a)
    modified_payload = _image_payload(b)

    if a is not None and b is None:
        return {
            "type": "image_deleted",
            "display_type": "image",
            "change_kind": "delete",
            "original": original_payload,
            "modified": None,
            "original_img": original_payload,
            "modified_img": None,
            "left_context": original_payload,
            "right_context": None,
            "diff_spans": None,
        }

    if b is not None and a is None:
        return {
            "type": "image_added",
            "display_type": "image",
            "change_kind": "insert",
            "original": None,
            "modified": modified_payload,
            "original_img": None,
            "modified_img": modified_payload,
            "left_context": None,
            "right_context": modified_payload,
            "diff_spans": None,
        }

    return {
        "type": "image_modified",
        "display_type": "image",
        "change_kind": "replace",
        "original": original_payload,
        "modified": modified_payload,
        "original_img": original_payload,
        "modified_img": modified_payload,
        "left_context": original_payload,
        "right_context": modified_payload,
        "diff_spans": None,
    }