from __future__ import annotations

from typing import List, Dict, Any, Optional

from services.models.docnode import DocNode
from services.diff.paragraph_diff import diff_words
from services.diff.image_diff import images_equal, build_image_change


def _serialize_node(node: Optional[DocNode]) -> Any:
    if node is None:
        return None

    return {
        "uid": getattr(node, "uid", None),
        "type": node.type,
        "content": node.content,
        "children": [_serialize_node(c) for c in (node.children or [])],
    }


def _cell_text(cell: Optional[DocNode]) -> str:
    if not cell:
        return ""

    return (cell.content.get("text") or "").strip()


def _row_text(row: Optional[DocNode]) -> str:
    if not row:
        return ""

    return (row.content.get("text") or "").strip()


def _row_cells(row: Optional[DocNode]) -> List[str]:
    if not row:
        return []

    cells = [c for c in (row.children or []) if c.type == "cell"]
    return [_cell_text(c) for c in cells]


def _diff_paragraph(a: DocNode, b: DocNode) -> Optional[Dict[str, Any]]:
    old = (a.content.get("text") or "")
    new = (b.content.get("text") or "")

    if old == new and not (a.children or []) and not (b.children or []):
        return None

    changes: List[Dict[str, Any]] = []

    if old != new:
        changes.append(
            {
                "type": "paragraph_modified",
                "original": a.content,
                "modified": b.content,
                "diff_spans": diff_words(old, new),
            }
        )

    a_imgs = [c for c in (a.children or []) if c.type == "image"]
    b_imgs = [c for c in (b.children or []) if c.type == "image"]

    max_img = max(len(a_imgs), len(b_imgs))

    for i in range(max_img):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None

        if images_equal(ai, bi):
            continue

        changes.append(build_image_change(ai, bi))

    if not changes:
        return None

    return {
        "type": "paragraph_container_modified",
        "original": _serialize_node(a),
        "modified": _serialize_node(b),
        "changes": changes,
    }


def _diff_cell(a: DocNode, b: DocNode) -> List[Dict[str, Any]]:
    changes: List[Dict[str, Any]] = []

    old_text = _cell_text(a)
    new_text = _cell_text(b)

    if old_text != new_text:
        changes.append(
            {
                "type": "cell_text_modified",
                "original_text": old_text,
                "modified_text": new_text,
                "diff_spans": diff_words(old_text, new_text),
            }
        )

    a_children = a.children or []
    b_children = b.children or []

    max_len = max(len(a_children), len(b_children))

    for i in range(max_len):
        ac = a_children[i] if i < len(a_children) else None
        bc = b_children[i] if i < len(b_children) else None

        if ac is None and bc is not None:
            changes.append(
                {
                    "type": f"{bc.type}_inserted",
                    "original": None,
                    "modified": _serialize_node(bc),
                }
            )
            continue

        if bc is None and ac is not None:
            changes.append(
                {
                    "type": f"{ac.type}_deleted",
                    "original": _serialize_node(ac),
                    "modified": None,
                }
            )
            continue

        if ac is None or bc is None:
            continue

        if ac.type == "paragraph" and bc.type == "paragraph":
            paragraph_change = _diff_paragraph(ac, bc)
            if paragraph_change:
                changes.append(paragraph_change)
            continue

        if ac.type == "image" and bc.type == "image":
            if not images_equal(ac, bc):
                changes.append(build_image_change(ac, bc))
            continue

        if ac.type == "table" and bc.type == "table":
            nested_changes = diff_table(ac, bc)
            if nested_changes:
                changes.append(
                    {
                        "type": "nested_table_modified",
                        "original": _serialize_node(ac),
                        "modified": _serialize_node(bc),
                        "changes": nested_changes,
                    }
                )
            continue

        if ac.type != bc.type:
            changes.append(
                {
                    "type": "node_type_changed",
                    "original": _serialize_node(ac),
                    "modified": _serialize_node(bc),
                }
            )

    return changes


def _get_rows(tbl: DocNode) -> List[DocNode]:
    return [c for c in (tbl.children or []) if c.type == "row"]


def _get_cells(row: DocNode) -> List[DocNode]:
    return [c for c in (row.children or []) if c.type == "cell"]


def diff_table(a_tbl: DocNode, b_tbl: DocNode) -> List[Dict[str, Any]]:
    changes: List[Dict[str, Any]] = []

    a_rows = _get_rows(a_tbl)
    b_rows = _get_rows(b_tbl)

    max_rows = max(len(a_rows), len(b_rows))

    for r in range(max_rows):
        ar = a_rows[r] if r < len(a_rows) else None
        br = b_rows[r] if r < len(b_rows) else None

        if ar is None and br is not None:
            changes.append(
                {
                    "type": "table_row_added",
                    "row_index": r,
                    "left_row": None,
                    "right_row": _serialize_node(br),
                    "left_cells": [],
                    "right_cells": _row_cells(br),
                    "right_text": _row_text(br),
                }
            )
            continue

        if br is None and ar is not None:
            changes.append(
                {
                    "type": "table_row_deleted",
                    "row_index": r,
                    "left_row": _serialize_node(ar),
                    "right_row": None,
                    "left_cells": _row_cells(ar),
                    "right_cells": [],
                    "left_text": _row_text(ar),
                }
            )
            continue

        if ar is None or br is None:
            continue

        row_changed = False
        row_cell_changes: List[Dict[str, Any]] = []

        a_cells = _get_cells(ar)
        b_cells = _get_cells(br)

        max_cells = max(len(a_cells), len(b_cells))

        for c in range(max_cells):
            ac = a_cells[c] if c < len(a_cells) else None
            bc = b_cells[c] if c < len(b_cells) else None

            if ac is None and bc is not None:
                row_changed = True
                row_cell_changes.append(
                    {
                        "type": "table_cell_added",
                        "col_index": c,
                        "left_cell": None,
                        "right_cell": _serialize_node(bc),
                        "left_text": "",
                        "right_text": _cell_text(bc),
                    }
                )
                continue

            if bc is None and ac is not None:
                row_changed = True
                row_cell_changes.append(
                    {
                        "type": "table_cell_deleted",
                        "col_index": c,
                        "left_cell": _serialize_node(ac),
                        "right_cell": None,
                        "left_text": _cell_text(ac),
                        "right_text": "",
                    }
                )
                continue

            if ac is None or bc is None:
                continue

            cell_changes = _diff_cell(ac, bc)

            if cell_changes:
                row_changed = True
                row_cell_changes.append(
                    {
                        "type": "table_cell_modified",
                        "col_index": c,
                        "left_cell": _serialize_node(ac),
                        "right_cell": _serialize_node(bc),
                        "left_text": _cell_text(ac),
                        "right_text": _cell_text(bc),
                        "changes": cell_changes,
                    }
                )

        if row_changed or _row_text(ar) != _row_text(br):
            changes.append(
                {
                    "type": "table_row_modified",
                    "row_index": r,
                    "left_row": _serialize_node(ar),
                    "right_row": _serialize_node(br),
                    "left_text": _row_text(ar),
                    "right_text": _row_text(br),
                    "left_cells": _row_cells(ar),
                    "right_cells": _row_cells(br),
                    "cell_changes": row_cell_changes,
                }
            )

    return changes