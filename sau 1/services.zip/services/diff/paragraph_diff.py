from __future__ import annotations

import difflib
from typing import List, Dict, Any


def _normalize_text(text: str) -> str:
    return " ".join((text or "").replace("\u00a0", " ").split()).strip()


def diff_words(old_text: str, new_text: str) -> List[Dict[str, Any]]:
    old_text = old_text or ""
    new_text = new_text or ""

    a = old_text.split()
    b = new_text.split()

    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)

    spans: List[Dict[str, Any]] = []

    old_cursor = 0
    new_cursor = 0

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        old_segment = " ".join(a[i1:i2]).strip()
        new_segment = " ".join(b[j1:j2]).strip()

        if tag == "equal":
            if old_segment:
                spans.append(
                    {
                        "type": "equal",
                        "action": "equal",
                        "side": "both",
                        "old_text": old_segment,
                        "new_text": old_segment,
                        "text": old_segment,
                        "old_start": old_cursor,
                        "old_end": old_cursor + len(old_segment),
                        "new_start": new_cursor,
                        "new_end": new_cursor + len(old_segment),
                    }
                )
                old_cursor += len(old_segment) + 1
                new_cursor += len(old_segment) + 1
            continue

        if tag == "delete":
            if old_segment:
                spans.append(
                    {
                        "type": "delete",
                        "action": "delete",
                        "side": "left",
                        "old_text": old_segment,
                        "new_text": "",
                        "text": old_segment,
                        "old_start": old_cursor,
                        "old_end": old_cursor + len(old_segment),
                        "new_start": new_cursor,
                        "new_end": new_cursor,
                    }
                )
                old_cursor += len(old_segment) + 1
            continue

        if tag == "insert":
            if new_segment:
                spans.append(
                    {
                        "type": "insert",
                        "action": "insert",
                        "side": "right",
                        "old_text": "",
                        "new_text": new_segment,
                        "text": new_segment,
                        "old_start": old_cursor,
                        "old_end": old_cursor,
                        "new_start": new_cursor,
                        "new_end": new_cursor + len(new_segment),
                    }
                )
                new_cursor += len(new_segment) + 1
            continue

        if tag == "replace":
            if old_segment:
                spans.append(
                    {
                        "type": "delete",
                        "action": "replace_old",
                        "side": "left",
                        "old_text": old_segment,
                        "new_text": "",
                        "text": old_segment,
                        "old_start": old_cursor,
                        "old_end": old_cursor + len(old_segment),
                        "new_start": new_cursor,
                        "new_end": new_cursor,
                    }
                )
                old_cursor += len(old_segment) + 1

            if new_segment:
                spans.append(
                    {
                        "type": "insert",
                        "action": "replace_new",
                        "side": "right",
                        "old_text": "",
                        "new_text": new_segment,
                        "text": new_segment,
                        "old_start": old_cursor,
                        "old_end": old_cursor,
                        "new_start": new_cursor,
                        "new_end": new_cursor + len(new_segment),
                    }
                )
                new_cursor += len(new_segment) + 1

    return [
        {
            "old_full_text": _normalize_text(old_text),
            "new_full_text": _normalize_text(new_text),
            "spans": spans,
        }
    ]