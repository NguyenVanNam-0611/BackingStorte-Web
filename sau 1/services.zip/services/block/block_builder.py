from __future__ import annotations

from typing import List, Optional

from services.models.docnode import DocNode
from services.models.block import Block
from services.block.signature import signature


def build_blocks(doc_root: DocNode) -> List[Block]:
    blocks: List[Block] = []

    current_heading: Optional[str] = None
    current_heading_level: int = 0
    heading_stack: List[dict] = []

    for node in doc_root.children:
        if node.type == "heading":
            heading_text = (node.content.get("text") or "").strip()
            heading_level = int(node.content.get("level", 1) or 1)

            while heading_stack and heading_stack[-1]["level"] >= heading_level:
                heading_stack.pop()

            heading_stack.append(
                {
                    "text": heading_text,
                    "level": heading_level,
                }
            )

            current_heading = " > ".join(
                x["text"]
                for x in heading_stack
                if x["text"]
            )

            current_heading_level = heading_level

            blocks.append(
                Block(
                    type="heading",
                    node=node,
                    signature=signature(node),
                    heading_ctx=current_heading,
                    heading_level=current_heading_level,
                    order=node.order,
                    uid=node.uid,
                )
            )
            continue

        blocks.append(
            Block(
                type=node.type,
                node=node,
                signature=signature(node),
                heading_ctx=current_heading,
                heading_level=current_heading_level,
                order=node.order,
                uid=node.uid,
            )
        )

    return sorted(
        blocks,
        key=lambda x: (
            x.order if x.order is not None else 0,
            x.uid or "",
        ),
    )