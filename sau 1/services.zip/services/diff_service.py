from __future__ import annotations

from typing import Dict, Any, List

from services.extractor.document import extract_doc_tree
from services.block.block_builder import build_blocks
from services.align.sequence_align import align_blocks
from services.serializer.json_builder import build_ui_json


class DiffService:
    def _sort_section_changes(self, sections: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        for section in sections:
            changes = section.get("changes", [])

            changes.sort(
                key=lambda x: (
                    x.get("order", 0),
                    x.get("id", 0),
                )
            )

            section["changes"] = changes

        return sections

    def _normalize_section(self, section: Dict[str, Any]) -> Dict[str, Any]:
        heading = section.get("heading") or "(No heading)"
        changes = section.get("changes", [])

        normalized_changes = []

        for ch in changes:
            original = ch.get("original")
            modified = ch.get("modified")

            order_candidates = []

            if isinstance(original, dict):
                order_candidates.append(original.get("order", 0))

            if isinstance(modified, dict):
                order_candidates.append(modified.get("order", 0))

            change_order = min([x for x in order_candidates if x is not None], default=0)

            normalized_changes.append(
                {
                    **ch,
                    "heading": heading,
                    "order": change_order,
                    "display_type": ch.get("display_type")
                    or ch.get("type", "").replace("_modified", "")
                    .replace("_inserted", "")
                    .replace("_deleted", ""),
                    "left": {
                        "exists": original is not None,
                        "data": original,
                    },
                    "right": {
                        "exists": modified is not None,
                        "data": modified,
                    },
                }
            )

        return {
            "heading": heading,
            "changes": normalized_changes,
        }

    def compare(self, original_path: str, modified_path: str) -> Dict[str, Any]:
        original_root = extract_doc_tree(original_path)
        modified_root = extract_doc_tree(modified_path)

        original_blocks = build_blocks(original_root)
        modified_blocks = build_blocks(modified_root)

        opcodes = align_blocks(original_blocks, modified_blocks)

        result = build_ui_json(
            original_blocks,
            modified_blocks,
            opcodes,
        )

        sections = result.get("sections", [])
        normalized_sections = [
            self._normalize_section(section)
            for section in sections
        ]

        normalized_sections = self._sort_section_changes(normalized_sections)

        total_changes = sum(
            len(section.get("changes", []))
            for section in normalized_sections
        )

        return {
            "original_file": original_path,
            "modified_file": modified_path,
            "total_sections": len(normalized_sections),
            "total_changes": total_changes,
            "sections": normalized_sections,
        }