from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class DocNode:
    type: str
    content: Dict[str, Any] = field(default_factory=dict)
    children: List["DocNode"] = field(default_factory=list)
    uid: Optional[str] = None
    parent: Optional["DocNode"] = field(default=None, repr=False)

    def add_child(self, child: "DocNode") -> None:
        child.parent = self
        self.children.append(child)

    def is_leaf(self) -> bool:
        return len(self.children) == 0

    def walk(self) -> List["DocNode"]:
        nodes = [self]
        for c in self.children:
            nodes.extend(c.walk())
        return nodes

    def __repr__(self) -> str:
        return f"DocNode(type={self.type}, children={len(self.children)})"