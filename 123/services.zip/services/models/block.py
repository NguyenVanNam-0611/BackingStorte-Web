from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from services.models.docnode import DocNode


@dataclass
class Block:
    type: str
    node: DocNode
    signature: str
    heading_ctx: Optional[str] = None

    def __repr__(self) -> str:
        return f"Block(type={self.type}, signature={self.signature})"