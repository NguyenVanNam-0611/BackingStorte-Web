from __future__ import annotations

from typing import List, Optional

from services.models.docnode import DocNode
from services.models.block import Block
from services.block.signature import signature


def build_blocks(doc_root: DocNode) -> List[Block]:
    blocks: List[Block] = []
    current_heading: Optional[str] = None

    for node in doc_root.children:
        if node.type == "heading":
            current_heading = node.content.get("text") or ""
            blocks.append(
                Block(
                    type="heading",
                    node=node,
                    signature=signature(node),
                    heading_ctx=current_heading,
                )
            )
            continue

        blocks.append(
            Block(
                type=node.type,
                node=node,
                signature=signature(node),
                heading_ctx=current_heading,
            )
        )

    return blocks