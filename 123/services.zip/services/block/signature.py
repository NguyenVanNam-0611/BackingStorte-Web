from __future__ import annotations

import re
from services.models.docnode import DocNode


def _norm_text(s: str) -> str:
    return " ".join((s or "").replace("\u00a0", " ").split()).strip()


def signature(node: DocNode) -> str:
    t = node.type

    if t == "heading":
        txt = _norm_text(node.content.get("text", ""))
        return "H:" + txt[:200]

    if t == "paragraph":
        txt = _norm_text(node.content.get("text", ""))
        return "P:" + txt[:80]

    if t == "table":
        r = int(node.content.get("rows", 0) or 0)
        c = int(node.content.get("cols", 0) or 0)
        return f"T:{r}x{c}"

    if t == "image":
        w = int(node.content.get("width", 0) or 0)
        h = int(node.content.get("height", 0) or 0)
        return f"I:{w}x{h}"

    if t == "shape":
        p = int(node.content.get("p", 0) or 0)
        i = int(node.content.get("img", 0) or 0)
        tb = int(node.content.get("tbl", 0) or 0)
        return f"S:{p}p+{i}i+{tb}t"

    return f"U:{t}"
