from __future__ import annotations

import re
from typing import Iterator, Union, Optional, List

from docx import Document
from docx.document import Document as _Document
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import _Cell, Table
from docx.text.paragraph import Paragraph

from services.models.docnode import DocNode
from services.extractor.image import extract_inline_images
from services.extractor.shape import extract_shapes_from_paragraph


BlockItem = Union[Paragraph, Table]


def _norm_text(s: str) -> str:
    return " ".join((s or "").replace("\u00a0", " ").split()).strip()


def _heading_level(style_name: str) -> int:
    if not style_name:
        return 0
    m = re.search(r"heading\s*(\d+)", style_name.strip().lower())
    return int(m.group(1)) if m else 0


def _is_heading(par: Paragraph) -> bool:
    name = par.style.name if par.style else ""
    return (name or "").strip().lower().startswith("heading")


def _iter_block_items(parent: Union[_Document, _Cell]) -> Iterator[BlockItem]:
    if isinstance(parent, _Document):
        parent_elm = parent.element.body
    elif isinstance(parent, _Cell):
        parent_elm = parent._tc
    else:
        raise ValueError("unsupported parent")

    for child in parent_elm.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, parent)
        elif isinstance(child, CT_Tbl):
            yield Table(child, parent)


def _extract_paragraph_nodes(par: Paragraph, uid: str) -> List[DocNode]:
    text = _norm_text(par.text)
    imgs = extract_inline_images(par, uid_prefix=f"{uid}.img")
    shapes = extract_shapes_from_paragraph(par, uid_prefix=f"{uid}.shp")

    if _is_heading(par):
        style_name = par.style.name if par.style else ""
        return [
            DocNode(
                type="heading",
                content={"text": text, "level": _heading_level(style_name)},
                uid=uid,
            )
        ]

    nodes: List[DocNode] = []

    if text or imgs:
        pnode = DocNode(type="paragraph", content={"text": text}, uid=uid)
        for im in imgs:
            pnode.add_child(im)
        nodes.append(pnode)

    for sh in shapes:
        nodes.append(sh)

    return nodes


def _extract_cell(cell: _Cell, uid_prefix: str) -> DocNode:
    cell_node = DocNode(type="cell", content={}, uid=uid_prefix)
    n = 0
    for item in _iter_block_items(cell):
        n += 1
        if isinstance(item, Paragraph):
            nodes = _extract_paragraph_nodes(item, uid=f"{uid_prefix}.p{n}")
            for x in nodes:
                cell_node.add_child(x)
        else:
            cell_node.add_child(_extract_table(item, uid=f"{uid_prefix}.t{n}"))
    return cell_node


def _extract_table(tbl: Table, uid: Optional[str] = None) -> DocNode:
    rows = len(tbl.rows)
    cols = len(tbl.columns) if rows > 0 else 0
    table_node = DocNode(type="table", content={"rows": rows, "cols": cols}, uid=uid)

    for r_idx, row in enumerate(tbl.rows):
        row_uid = f"{uid}.r{r_idx}" if uid else None
        row_node = DocNode(type="row", content={"row_index": r_idx}, uid=row_uid)
        table_node.add_child(row_node)

        for c_idx, cell in enumerate(row.cells):
            cell_uid = f"{uid}.r{r_idx}.c{c_idx}" if uid else f"cell.r{r_idx}.c{c_idx}"
            cell_node = _extract_cell(cell, uid_prefix=cell_uid)
            cell_node.content["row_index"] = r_idx
            cell_node.content["col_index"] = c_idx
            row_node.add_child(cell_node)

    return table_node


def extract_doc_tree(docx_path: str) -> DocNode:
    doc = Document(docx_path)
    root = DocNode(type="document", content={"source": docx_path})

    i = 0
    for item in _iter_block_items(doc):
        i += 1
        uid = f"n{i}"
        if isinstance(item, Paragraph):
            nodes = _extract_paragraph_nodes(item, uid=uid)
            for x in nodes:
                root.add_child(x)
        else:
            root.add_child(_extract_table(item, uid=uid))

    return root
