from __future__ import annotations

from typing import List, Optional, Any
import uuid

from services.models.docnode import DocNode
from services.utils.hash import image_hash_from_bytes, bytes_to_data_uri, safe_sha256


_NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    "v": "urn:schemas-microsoft-com:vml",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
}


def _norm_text(s: str) -> str:
    return " ".join((s or "").replace("\u00a0", " ").split()).strip()


def _emu_to_int(v: Any) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _extract_images_from_xml(xml_elem, part, uid_prefix: str) -> List[DocNode]:
    nodes: List[DocNode] = []
    blips = xml_elem.xpath(".//a:blip/@r:embed")
    if not blips:
        return nodes

    exts = xml_elem.xpath(".//wp:extent")
    cx = cy = 0
    if exts:
        cx = _emu_to_int(exts[0].get("cx"))
        cy = _emu_to_int(exts[0].get("cy"))

    for i, rid in enumerate(blips, start=1):
        p = part.related_parts.get(rid) if part else None
        if not p:
            continue
        blob = p.blob
        mime = getattr(p, "content_type", None) or "image/png"
        nodes.append(
            DocNode(
                type="image",
                content={
                    "rid": rid,
                    "hash": image_hash_from_bytes(blob),
                    "sha256": safe_sha256(blob),
                    "mime": mime,
                    "width_emu": cx,
                    "height_emu": cy,
                    "data_uri": bytes_to_data_uri(blob, mime=mime),
                },
                uid=f"{uid_prefix}.i{i}",
            )
        )
    return nodes


def _parse_p_xml(p_xml, part, uid_prefix: str) -> List[DocNode]:
    text = _norm_text("".join(p_xml.xpath(".//w:t/text()")))
    out: List[DocNode] = []
    pnode = DocNode(type="paragraph", content={"text": text}, uid=f"{uid_prefix}.p")
    out.append(pnode)

    imgs = _extract_images_from_xml(p_xml, part, uid_prefix=f"{uid_prefix}.img")
    out.extend(imgs)
    return [n for n in out if not (n.type == "paragraph" and not n.content.get("text") and len(out) == 1)]


def _parse_tbl_xml(tbl_xml, part, uid_prefix: str) -> DocNode:
    rows_xml = tbl_xml.xpath("./w:tr")
    row_count = len(rows_xml)
    col_count = 0
    for tr in rows_xml:
        tcs = tr.xpath("./w:tc")
        col_count = max(col_count, len(tcs))

    tnode = DocNode(type="table", content={"rows": row_count, "cols": col_count}, uid=f"{uid_prefix}.t")

    for r_idx, tr in enumerate(rows_xml):
        rnode = DocNode(type="row", content={"row_index": r_idx}, uid=f"{uid_prefix}.r{r_idx}")
        tnode.add_child(rnode)

        tcs = tr.xpath("./w:tc", namespaces=_NS)
        for c_idx, tc in enumerate(tcs):
            cnode = DocNode(
                type="cell",
                content={"row_index": r_idx, "col_index": c_idx},
                uid=f"{uid_prefix}.r{r_idx}.c{c_idx}",
            )
            rnode.add_child(cnode)

            children = []
            for child in tc.iterchildren():
                if child.tag == f"{{{_NS['w']}}}p":
                    children.extend(_parse_p_xml(child, part, uid_prefix=f"{uid_prefix}.r{r_idx}.c{c_idx}.p{len(children)+1}"))
                elif child.tag == f"{{{_NS['w']}}}tbl":
                    children.append(_parse_tbl_xml(child, part, uid_prefix=f"{uid_prefix}.r{r_idx}.c{c_idx}.t{len(children)+1}"))

            for ch in children:
                cnode.add_child(ch)

    return tnode


def _parse_txbx_content(txbx_xml, part, uid_prefix: str) -> DocNode:
    sid = str(uuid.uuid4().hex)
    shape = DocNode(type="shape", content={"shape_id": sid}, uid=uid_prefix)

    children: List[DocNode] = []
    for child in txbx_xml.iterchildren():
        if child.tag == f"{{{_NS['w']}}}p":
            children.extend(_parse_p_xml(child, part, uid_prefix=f"{uid_prefix}.{len(children)+1}"))
        elif child.tag == f"{{{_NS['w']}}}tbl":
            children.append(_parse_tbl_xml(child, part, uid_prefix=f"{uid_prefix}.{len(children)+1}"))

    p_count = sum(1 for x in children if x.type == "paragraph")
    i_count = sum(1 for x in children if x.type == "image")
    t_count = sum(1 for x in children if x.type == "table")
    shape.content.update({"p": p_count, "img": i_count, "tbl": t_count})

    for ch in children:
        shape.add_child(ch)

    return shape


def extract_shapes_from_paragraph(paragraph, uid_prefix: str = "shp") -> List[DocNode]:
    out: List[DocNode] = []
    part = getattr(paragraph, "part", None)

    idx = 0
    for run in paragraph.runs:
        r = run._r
        if r is None:
            continue

        txbxs = r.xpath(".//w:txbxContent")
        for tx in txbxs:
            idx += 1
            out.append(_parse_txbx_content(tx, part, uid_prefix=f"{uid_prefix}.{idx}"))

    return out