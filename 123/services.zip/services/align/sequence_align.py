from __future__ import annotations

import difflib
from typing import List, Tuple
from services.models.block import Block


Opcode = Tuple[str, int, int, int, int]


def align_blocks(a_blocks: List[Block], b_blocks: List[Block]) -> List[Opcode]:
    a = [b.signature for b in a_blocks]
    c = [b.signature for b in b_blocks]
    sm = difflib.SequenceMatcher(a=a, b=c, autojunk=False)
    return sm.get_opcodes()
