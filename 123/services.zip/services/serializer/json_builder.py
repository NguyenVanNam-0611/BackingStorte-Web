from __future__ import annotations

from typing import Dict, List, Any, Optional
from services.models.block import Block
from services.diff.paragraph_diff import diff_words
from services.diff.table_diff import diff_table
from services.diff.shape_diff import diff_shape


def _section_key(h: Optional[str]) -> str:
    return h if h else "(No heading)"


def build_ui_json(a_blocks: List[Block], b_blocks: List[Block], opcodes) -> Dict[str, Any]:
    sections: Dict[str, List[Dict[str, Any]]] = {}
    cid = 1

    def add_change(heading: Optional[str], change: Dict[str, Any]):
        key = _section_key(heading)
        sections.setdefault(key, []).append(change)

    for tag, i1, i2, j1, j2 in opcodes:
        if tag == "equal":
            continue

        if tag == "insert":
            for b in b_blocks[j1:j2]:
                add_change(
                    b.heading_ctx,
                    {
                        "id": cid,
                        "type": f"{b.type}_inserted",
                        "original": None,
                        "modified": b.node.content if b.type != "table" else {"table": b.node.content},
                        "diff_spans": None,
                    },
                )
                cid += 1

        elif tag == "delete":
            for a in a_blocks[i1:i2]:
                add_change(
                    a.heading_ctx,
                    {
                        "id": cid,
                        "type": f"{a.type}_deleted",
                        "original": a.node.content if a.type != "table" else {"table": a.node.content},
                        "modified": None,
                        "diff_spans": None,
                    },
                )
                cid += 1

        elif tag == "replace":
            pairs = min(i2 - i1, j2 - j1)

            for k in range(pairs):
                a = a_blocks[i1 + k]
                b = b_blocks[j1 + k]
                heading = b.heading_ctx or a.heading_ctx

                if a.type == "paragraph" and b.type == "paragraph":
                    old = a.node.content.get("text", "") or ""
                    new = b.node.content.get("text", "") or ""
                    add_change(
                        heading,
                        {
                            "id": cid,
                            "type": "paragraph_modified",
                            "original": a.node.content,
                            "modified": b.node.content,
                            "diff_spans": diff_words(old, new),
                        },
                    )
                    cid += 1
                    continue
                if a.type == "shape" and b.type == "shape":
                    s_changes = diff_shape(a.node, b.node)
                    add_change(
                        heading,
                        {
                            "id": cid,
                            "type": "shape_modified",
                            "original": {"shape": a.node.content},
                            "modified": {"shape": b.node.content},
                            "changes": s_changes,
                        },
                    )
                    cid += 1
                    continue
                if a.type == "table" and b.type == "table":
                    t_changes = diff_table(a.node, b.node)
                    if not t_changes:
                        continue
                    for ch in t_changes:
                        ch["id"] = cid
                        add_change(heading, ch)
                        cid += 1
                    continue

                add_change(
                    heading,
                    {
                        "id": cid,
                        "type": f"{a.type}_to_{b.type}_modified",
                        "original": a.node.content,
                        "modified": b.node.content,
                        "diff_spans": None,
                    },
                )
                cid += 1

            for a in a_blocks[i1 + pairs : i2]:
                add_change(
                    a.heading_ctx,
                    {
                        "id": cid,
                        "type": f"{a.type}_deleted",
                        "original": a.node.content,
                        "modified": None,
                        "diff_spans": None,
                    },
                )
                cid += 1

            for b in b_blocks[j1 + pairs : j2]:
                add_change(
                    b.heading_ctx,
                    {
                        "id": cid,
                        "type": f"{b.type}_inserted",
                        "original": None,
                        "modified": b.node.content,
                        "diff_spans": None,
                    },
                )
                cid += 1

    return {"sections": [{"heading": h, "changes": ch} for h, ch in sections.items()]}