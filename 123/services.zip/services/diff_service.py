from __future__ import annotations

from typing import Dict, Any

from services.extractor.document import extract_doc_tree
from services.block.block_builder import build_blocks
from services.align.sequence_align import align_blocks
from services.serializer.json_builder import build_ui_json


class DiffService:
    def compare(self, original_path: str, modified_path: str) -> Dict[str, Any]:
        o_root = extract_doc_tree(original_path)
        m_root = extract_doc_tree(modified_path)

        o_blocks = build_blocks(o_root)
        m_blocks = build_blocks(m_root)

        opcodes = align_blocks(o_blocks, m_blocks)

        return build_ui_json(o_blocks, m_blocks, opcodes)