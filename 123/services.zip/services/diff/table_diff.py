from __future__ import annotations

from typing import List, Dict, Any, Optional

from services.models.docnode import DocNode
from services.diff.paragraph_diff import diff_words
from services.diff.image_diff import images_equal, build_image_change


def _serialize_node(node: Optional[DocNode]) -> Any:
    if node is None:
        return None
    return {
        "type": node.type,
        "content": node.content,
        "children": [_serialize_node(c) for c in (node.children or [])],
    }


def _diff_paragraph(a: DocNode, b: DocNode) -> Optional[Dict[str, Any]]:
    old = (a.content.get("text") or "")
    new = (b.content.get("text") or "")

    # nếu text giống nhau và không có children -> no change
    if old == new and not (a.children or []) and not (b.children or []):
        return None

    changes: List[Dict[str, Any]] = []

    if old != new:
        changes.append({
            "type": "paragraph_modified",
            "original": a.content,
            "modified": b.content,
            "diff_spans": diff_words(old, new)
        })

    a_imgs = [c for c in (a.children or []) if c.type == "image"]
    b_imgs = [c for c in (b.children or []) if c.type == "image"]
    m = max(len(a_imgs), len(b_imgs))

    for i in range(m):
        ai = a_imgs[i] if i < len(a_imgs) else None
        bi = b_imgs[i] if i < len(b_imgs) else None
        if images_equal(ai, bi):
            continue
        changes.append(build_image_change(ai, bi))

    if not changes:
        return None

    return {
        "type": "paragraph_container_modified",
        "original": _serialize_node(a),
        "modified": _serialize_node(b),
        "changes": changes
    }


def _diff_cell(a: DocNode, b: DocNode) -> List[Dict[str, Any]]:
    
    changes: List[Dict[str, Any]] = []
    a_children = a.children or []
    b_children = b.children or []

    max_len = max(len(a_children), len(b_children))
    for i in range(max_len):
        ac = a_children[i] if i < len(a_children) else None
        bc = b_children[i] if i < len(b_children) else None

        if ac is None and bc is not None:
            changes.append({
                "type": f"{bc.type}_inserted",
                "original": None,
                "modified": _serialize_node(bc)
            })
            continue

        if bc is None and ac is not None:
            changes.append({
                "type": f"{ac.type}_deleted",
                "original": _serialize_node(ac),
                "modified": None
            })
            continue

        if ac is None or bc is None:
            continue

        # ----- paragraph vs paragraph -----
        if ac.type == "paragraph" and bc.type == "paragraph":
            d = _diff_paragraph(ac, bc)
            if d:
                changes.append(d)
            continue

        # ----- image vs image -----
        if ac.type == "image" and bc.type == "image":
            if not images_equal(ac, bc):
                changes.append(build_image_change(ac, bc))
            continue

        # ----- table vs table (nested table) -----
        if ac.type == "table" and bc.type == "table":
            sub = diff_table(ac, bc)
            if sub:
                changes.append({
                    "type": "nested_table_modified",
                    "original": _serialize_node(ac),
                    "modified": _serialize_node(bc),
                    "changes": sub
                })
            continue

        # ✅ IMPORTANT: paragraph -> table (nested table inserted)
        if ac.type == "paragraph" and bc.type == "table":
            changes.append({
                "type": "nested_table_inserted",
                "original": _serialize_node(ac),
                "modified": _serialize_node(bc)
            })
            continue

        # ✅ IMPORTANT: table -> paragraph (nested table deleted)
        if ac.type == "table" and bc.type == "paragraph":
            changes.append({
                "type": "nested_table_deleted",
                "original": _serialize_node(ac),
                "modified": _serialize_node(bc)
            })
            continue

        # (optional) image -> table
        if ac.type == "image" and bc.type == "table":
            changes.append({
                "type": "nested_table_inserted",
                "original": _serialize_node(ac),
                "modified": _serialize_node(bc)
            })
            continue

        # (optional) table -> image
        if ac.type == "table" and bc.type == "image":
            changes.append({
                "type": "nested_table_deleted",
                "original": _serialize_node(ac),
                "modified": _serialize_node(bc)
            })
            continue

        # ----- fallback for other type changes -----
        if ac.type != bc.type:
            changes.append({
                "type": "node_type_changed",
                "original": _serialize_node(ac),
                "modified": _serialize_node(bc)
            })

    return changes


def _get_rows(tbl: DocNode) -> List[DocNode]:
    return [c for c in (tbl.children or []) if c.type == "row"]


def _get_cells(row: DocNode) -> List[DocNode]:
    return [c for c in (row.children or []) if c.type == "cell"]


def diff_table(a_tbl: DocNode, b_tbl: DocNode) -> List[Dict[str, Any]]:
    changes: List[Dict[str, Any]] = []
    a_rows = _get_rows(a_tbl)
    b_rows = _get_rows(b_tbl)

    max_len = max(len(a_rows), len(b_rows))

    for r in range(max_len):
        ar = a_rows[r] if r < len(a_rows) else None
        br = b_rows[r] if r < len(b_rows) else None

        if ar is None and br is not None:
            changes.append({
                "type": "table_row_added",
                "row_index": r,
                "row": _serialize_node(br)
            })
            continue

        if br is None and ar is not None:
            changes.append({
                "type": "table_row_deleted",
                "row_index": r,
                "row": _serialize_node(ar)
            })
            continue

        if ar is None or br is None:
            continue

        a_cells = _get_cells(ar)
        b_cells = _get_cells(br)
        max_c = max(len(a_cells), len(b_cells))

        for c in range(max_c):
            ac = a_cells[c] if c < len(a_cells) else None
            bc = b_cells[c] if c < len(b_cells) else None

            if ac is None and bc is not None:
                changes.append({
                    "type": "table_cell_added",
                    "row_index": r,
                    "col_index": c,
                    "original": None,
                    "modified": _serialize_node(bc)
                })
                continue

            if bc is None and ac is not None:
                changes.append({
                    "type": "table_cell_deleted",
                    "row_index": r,
                    "col_index": c,
                    "original": _serialize_node(ac),
                    "modified": None
                })
                continue

            if ac is None or bc is None:
                continue

            cell_changes = _diff_cell(ac, bc)
            if cell_changes:
                changes.append({
                    "type": "table_cell_modified",
                    "row_index": r,
                    "col_index": c,
                    "original": _serialize_node(ac),
                    "modified": _serialize_node(bc),
                    "changes": cell_changes
                })

    return changes
