from __future__ import annotations

from typing import Dict, Any, Optional
from services.models.docnode import DocNode


def images_equal(a: Optional[DocNode], b: Optional[DocNode]) -> bool:
    if not a and not b:
        return True
    if not a or not b:
        return False
    if a.type != "image" or b.type != "image":
        return False
    return (a.content.get("hash") and a.content.get("hash") == b.content.get("hash")) or (
        a.content.get("sha256") == b.content.get("sha256")
    )


def build_image_change(a: Optional[DocNode], b: Optional[DocNode]) -> Dict[str, Any]:
    if a and not b:
        return {"type": "image_deleted", "original_img": a.content, "modified_img": None}
    if b and not a:
        return {"type": "image_added", "original_img": None, "modified_img": b.content}
    return {"type": "image_changed", "original_img": a.content if a else None, "modified_img": b.content if b else None}
