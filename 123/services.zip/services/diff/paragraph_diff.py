from __future__ import annotations

import difflib
from typing import List, Dict


def diff_words(old_text: str, new_text: str) -> List[Dict[str, str]]:
    a = (old_text or "").split()
    b = (new_text or "").split()
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)

    spans: List[Dict[str, str]] = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            txt = " ".join(a[i1:i2])
            if txt:
                spans.append({"op": "equal", "text": txt})
        elif tag == "delete":
            txt = " ".join(a[i1:i2])
            if txt:
                spans.append({"op": "delete", "text": txt})
        elif tag == "insert":
            txt = " ".join(b[j1:j2])
            if txt:
                spans.append({"op": "insert", "text": txt})
        elif tag == "replace":
            del_txt = " ".join(a[i1:i2])
            ins_txt = " ".join(b[j1:j2])
            if del_txt:
                spans.append({"op": "delete", "text": del_txt})
            if ins_txt:
                spans.append({"op": "insert", "text": ins_txt})

    return spans