from __future__ import annotations

from typing import List, Dict, Any, Optional
import difflib

from services.models.docnode import DocNode
from services.models.block import Block
from services.block.signature import signature
from services.diff.paragraph_diff import diff_words
from services.diff.table_diff import diff_table
from services.diff.image_diff import images_equal, build_image_change


def _serialize_node(node: Optional[DocNode]) -> Any:
    if node is None:
        return None
    return {
        "type": node.type,
        "content": node.content,
        "children": [_serialize_node(c) for c in node.children] if node.children else [],
    }


def _blocks_from_children(children: List[DocNode]) -> List[Block]:
    out: List[Block] = []
    for n in children:
        out.append(Block(type=n.type, node=n, signature=signature(n), heading_ctx=None))
    return out


def diff_shape(a_shape: DocNode, b_shape: DocNode) -> List[Dict[str, Any]]:
    a_blocks = _blocks_from_children(a_shape.children or [])
    b_blocks = _blocks_from_children(b_shape.children or [])

    sm = difflib.SequenceMatcher(
        a=[x.signature for x in a_blocks],
        b=[x.signature for x in b_blocks],
        autojunk=False,
    )
    ops = sm.get_opcodes()

    changes: List[Dict[str, Any]] = []
    cid = 1

    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal":
            continue

        if tag == "insert":
            for b in b_blocks[j1:j2]:
                changes.append({"id": cid, "type": f"{b.type}_inserted", "original": None, "modified": _serialize_node(b.node)})
                cid += 1
            continue

        if tag == "delete":
            for a in a_blocks[i1:i2]:
                changes.append({"id": cid, "type": f"{a.type}_deleted", "original": _serialize_node(a.node), "modified": None})
                cid += 1
            continue

        if tag == "replace":
            pairs = min(i2 - i1, j2 - j1)

            for k in range(pairs):
                a = a_blocks[i1 + k].node
                b = b_blocks[j1 + k].node

                if a.type == "paragraph" and b.type == "paragraph":
                    old = a.content.get("text", "") or ""
                    new = b.content.get("text", "") or ""
                    if old != new:
                        changes.append(
                            {
                                "id": cid,
                                "type": "paragraph_modified",
                                "original": a.content,
                                "modified": b.content,
                                "diff_spans": diff_words(old, new),
                            }
                        )
                        cid += 1
                    continue

                if a.type == "table" and b.type == "table":
                    t_changes = diff_table(a, b)
                    for ch in t_changes:
                        ch["id"] = cid
                        changes.append(ch)
                        cid += 1
                    continue

                if a.type == "image" and b.type == "image":
                    if not images_equal(a, b):
                        ch = build_image_change(a, b)
                        ch["id"] = cid
                        changes.append(ch)
                        cid += 1
                    continue

                changes.append({"id": cid, "type": f"{a.type}_to_{b.type}_modified", "original": _serialize_node(a), "modified": _serialize_node(b)})
                cid += 1

            for a in a_blocks[i1 + pairs : i2]:
                changes.append({"id": cid, "type": f"{a.type}_deleted", "original": _serialize_node(a.node), "modified": None})
                cid += 1

            for b in b_blocks[j1 + pairs : j2]:
                changes.append({"id": cid, "type": f"{b.type}_inserted", "original": None, "modified": _serialize_node(b.node)})
                cid += 1

    return changes