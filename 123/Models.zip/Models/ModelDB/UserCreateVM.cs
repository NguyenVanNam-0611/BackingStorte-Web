﻿namespace TestUI.Models.ModelDB
{
    public class UserCreateVM
    {
        public int UserId { get; set; }

        public string Username { get; set; }

        // ⚠️ BẮT BUỘC nullable để Edit không bị lỗi
        public string? Password { get; set; }

        public string FullName { get; set; }
        public string Email { get; set; }
        public bool IsActive { get; set; }

        public int RoleId { get; set; }
    }
}
