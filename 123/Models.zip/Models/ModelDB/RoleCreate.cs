﻿namespace TestUI.Models.ModelDB
{
    public class RoleCreate
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string Description { get; set; }
    }
}
