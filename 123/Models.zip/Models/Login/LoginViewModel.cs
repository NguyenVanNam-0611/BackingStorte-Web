﻿using System.ComponentModel.DataAnnotations;

namespace TestUI.Models.Login
{
    public class LoginViewModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
