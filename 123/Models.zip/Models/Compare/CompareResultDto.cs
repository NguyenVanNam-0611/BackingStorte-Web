﻿namespace TestUI.Models.Compare
{
    public class CompareResultDto
    {
        public List<CompareSectionDto> Sections { get; set; }
    }
}
