﻿namespace TestUI.Models.Compare
{
    public class CompareChangeDto
    {
        public int Id { get; set; }
        public string Type { get; set; }     
        public object Original { get; set; }
        public object Modified { get; set; }
        public List<DiffSpanDto> Diff_Spans { get; set; }
    }
}
