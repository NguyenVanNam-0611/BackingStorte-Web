﻿namespace TestUI.Models.Compare
{
    public class JobStatusDto
    {
        public string Job_Id { get; set; }
        public string Status { get; set; }   
        public CompareResultDto Compare { get; set; }
        public string Error { get; set; }
    }
}
