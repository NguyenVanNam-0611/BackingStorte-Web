﻿namespace TestUI.Models.Compare
{
    public class CompareSectionDto
    {
        public string? Heading { get; set; }
        public List<CompareChangeDto>? Changes { get; set; }
    }
}
