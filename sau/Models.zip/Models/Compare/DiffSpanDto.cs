﻿namespace TestUI.Models.Compare
{

    public class DiffSpanDto
    {
        public string? Op { get; set; }
        public string? Text { get; set; }
    }

}
