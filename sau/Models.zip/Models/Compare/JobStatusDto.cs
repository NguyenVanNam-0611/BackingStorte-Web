﻿namespace TestUI.Models.Compare
{
    public class JobStatusDto
    {
        public string? Job_Id { get; set; }
        public string? Status { get; set; }
        public string? Error { get; set; }

        public string? Original_File_Name { get; set; }
        public string? Modified_File_Name { get; set; }

        public CompareResultDto? Compare { get; set; }
    }
}
