﻿namespace TestUI.Models.Compare
{
    public class ImageDto
    {
        public string? Data_Uri { get; set; }
        public string? Hash { get; set; }
        public string? Sha256 { get; set; }
    }
}
