﻿namespace TestUI.Models.Compare
{
    public class CompareChangeDto
    {
        public int Id { get; set; }
        public string? Type { get; set; }

        public object? Original { get; set; }
        public object? Modified { get; set; }

        public object? Original_Row { get; set; }
        public object? Modified_Row { get; set; }

        public object? Row { get; set; }

        public int? Row_Index { get; set; }
        public int? Col_Index { get; set; }

        public ImageDto? Original_Img { get; set; }
        public ImageDto? Modified_Img { get; set; }

        public List<DiffSpanDto>? Diff_Spans { get; set; }

        public List<CompareChangeDto>? Changes { get; set; }
    }

}
