﻿namespace TestUI.Models.Compare
{
    public class DocNodeDto
    {
        public string? Type { get; set; }
        public Dictionary<string, object>? Content { get; set; }
        public List<DocNodeDto>? Children { get; set; }
    }
}
